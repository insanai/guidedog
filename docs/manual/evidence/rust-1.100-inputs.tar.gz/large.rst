A larger guide
==============

Section 0000
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0001
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0002
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0003
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0004
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0005
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0006
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0007
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0008
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0009
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0010
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0011
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0012
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0013
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0014
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0015
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0016
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0017
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0018
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0019
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0020
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0021
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0022
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0023
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0024
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0025
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0026
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0027
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0028
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0029
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0030
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0031
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0032
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0033
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0034
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0035
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0036
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0037
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0038
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0039
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0040
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0041
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0042
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0043
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0044
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0045
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0046
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0047
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0048
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0049
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0050
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0051
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0052
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0053
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0054
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0055
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0056
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0057
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0058
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0059
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0060
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0061
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0062
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0063
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0064
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0065
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0066
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0067
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0068
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0069
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0070
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0071
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0072
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0073
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0074
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0075
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0076
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0077
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0078
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0079
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0080
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0081
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0082
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0083
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0084
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0085
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0086
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0087
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0088
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0089
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0090
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0091
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0092
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0093
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0094
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0095
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0096
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0097
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0098
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0099
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0100
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0101
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0102
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0103
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0104
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0105
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0106
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0107
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0108
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0109
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0110
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0111
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0112
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0113
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0114
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0115
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0116
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0117
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0118
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0119
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0120
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0121
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0122
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0123
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0124
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0125
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0126
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0127
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0128
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0129
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0130
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0131
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0132
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0133
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0134
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0135
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0136
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0137
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0138
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0139
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0140
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0141
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0142
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0143
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0144
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0145
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0146
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0147
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0148
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0149
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0150
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0151
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0152
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0153
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0154
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0155
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0156
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0157
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0158
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

Section 0159
------------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. We explain an observation and show its evidence. 

