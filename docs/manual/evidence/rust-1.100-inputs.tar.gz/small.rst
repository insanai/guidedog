A small guide
=============

We explain a *short* example with **strong text**, ``inline code`` and a `link <https://example.org>`_.

First steps
-----------

- Read the source.
- Render the page.
- Review the result.

.. note:: We keep a workspace for repeated conversions.

.. code-block:: rust

   let mut workspace = Workspace::new();
   workspace.reset();

